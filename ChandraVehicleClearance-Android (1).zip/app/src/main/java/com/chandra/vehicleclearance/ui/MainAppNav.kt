package com.chandra.vehicleclearance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chandra.vehicleclearance.data.AppUser

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppNav() {
    var loggedInUser by remember { mutableStateOf<AppUser?>(null) }
    var currentTab by remember { mutableStateOf(0) }

    if (loggedInUser == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "CHANDRA AUTOMOBILE",
                    fontWeight = FontWeight.Black,
                    fontSize = 22.sp,
                    color = Color.White
                )
                Text(
                    "INDIA PRIVATE LIMITED",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF38BDF8)
                )
                Text(
                    "VEHICLE CLEARANCE MANAGER",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8),
                    modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
                )

                var username by remember { mutableStateOf("") }
                var password by remember { mutableStateOf("") }

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("User ID") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        loggedInUser = AppUser(
                            id = "admin",
                            userId = "admin",
                            executiveName = "Administrator",
                            role = "ADMIN"
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Text("LOG IN TO DASHBOARD", fontWeight = FontWeight.Bold)
                }
            }
        }
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "CHANDRA VEHICLE CLEARANCE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                "CHANDRA AUTOMOBILE INDIA PRIVATE LIMITED",
                                fontSize = 10.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { loggedInUser = null }) {
                            Icon(Icons.Default.ExitToApp, contentDescription = "Logout", tint = Color(0xFFEF4444))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0F172A)) {
                    val tabs = listOf("Dashboard", "Clearance", "Records", "Reports", "Users")
                    tabs.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = currentTab == index,
                            onClick = { currentTab = index },
                            icon = {
                                when (index) {
                                    0 -> Icon(Icons.Default.Dashboard, contentDescription = null)
                                    1 -> Icon(Icons.Default.DirectionsCar, contentDescription = null)
                                    2 -> Icon(Icons.Default.ListAlt, contentDescription = null)
                                    3 -> Icon(Icons.Default.Assessment, contentDescription = null)
                                    else -> Icon(Icons.Default.People, contentDescription = null)
                                }
                            },
                            label = { Text(label, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color(0xFF090D1A))
            ) {
                when (currentTab) {
                    0 -> Text(
                        "Executive & Corporate Clearance Dashboard\nMulti-branch real-time cloud database active.",
                        color = Color.White,
                        modifier = Modifier.padding(16.dp)
                    )
                    1 -> Text(
                        "Vehicle Clearance Form (11 Particulars & 7 Offers)",
                        color = Color.White,
                        modifier = Modifier.padding(16.dp)
                    )
                    2 -> Text(
                        "All Vehicle Records (Filtered by assigned branch)",
                        color = Color.White,
                        modifier = Modifier.padding(16.dp)
                    )
                    3 -> Text(
                        "Branch Financial Reports & Excel Export",
                        color = Color.White,
                        modifier = Modifier.padding(16.dp)
                    )
                    else -> Text(
                        "Manage Users & Executive Permissions",
                        color = Color.White,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}
