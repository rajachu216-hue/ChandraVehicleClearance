# Chandra Vehicle Clearance Proguard rules
-keep class com.chandra.vehicleclearance.data.** { *; }
