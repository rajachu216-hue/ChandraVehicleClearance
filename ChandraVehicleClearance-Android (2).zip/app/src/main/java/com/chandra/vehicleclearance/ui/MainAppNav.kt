package com.chandra.vehicleclearance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chandra.vehicleclearance.data.AppUser

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppNav() {
    var loggedInUser by remember { mutableStateOf<AppUser?>(null) }
    var currentTab by remember { mutableStateOf(0) }

    if (loggedInUser == null) {
        // Login Screen - Clean White Theme
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF1F5F9)),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "CHANDRA AUTOMOBILE",
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        "INDIA PRIVATE LIMITED",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color(0xFF2563EB)
                    )
                    Text(
                        "VEHICLE CLEARANCE MANAGER",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B),
                        modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
                    )

                    var username by remember { mutableStateOf("") }
                    var password by remember { mutableStateOf("") }

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("User ID") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = {
                            loggedInUser = AppUser(
                                id = "admin",
                                userId = "admin",
                                executiveName = "Administrator",
                                role = "ADMIN"
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                    ) {
                        Text("LOG IN TO DASHBOARD", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    } else {
        // Authenticated Dashboard - Clean White Theme
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "CHANDRA VEHICLE CLEARANCE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                "CHANDRA AUTOMOBILE INDIA PRIVATE LIMITED",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { loggedInUser = null }) {
                            Icon(Icons.Default.ExitToApp, contentDescription = "Logout", tint = Color(0xFFDC2626))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val tabs = listOf("Dashboard", "Clearance", "Records", "Reports", "Users")
                    tabs.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = currentTab == index,
                            onClick = { currentTab = index },
                            icon = {
                                when (index) {
                                    0 -> Icon(Icons.Default.Dashboard, contentDescription = null)
                                    1 -> Icon(Icons.Default.DirectionsCar, contentDescription = null)
                                    2 -> Icon(Icons.Default.ListAlt, contentDescription = null)
                                    3 -> Icon(Icons.Default.Assessment, contentDescription = null)
                                    else -> Icon(Icons.Default.People, contentDescription = null)
                                }
                            },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color(0xFF2563EB),
                                selectedTextColor = Color(0xFF2563EB),
                                unselectedIconColor = Color(0xFF64748B),
                                unselectedTextColor = Color(0xFF64748B)
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color(0xFFF8FAFC))
            ) {
                when (currentTab) {
                    0 -> Text(
                        "Executive & Corporate Clearance Dashboard\nMulti-branch real-time cloud database active.",
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(16.dp)
                    )
                    1 -> Text(
                        "Vehicle Clearance Form (11 Particulars & 7 Offers)",
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(16.dp)
                    )
                    2 -> Text(
                        "All Vehicle Records (Filtered by assigned branch)",
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(16.dp)
                    )
                    3 -> Text(
                        "Branch Financial Reports & Excel Export",
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(16.dp)
                    )
                    else -> Text(
                        "Manage Users & Executive Permissions",
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}
