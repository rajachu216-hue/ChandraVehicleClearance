# CHANDRA AUTOMOBILE VEHICLE CLEARANCE - ANDROID NATIVE APP
## CHANDRA AUTOMOBILE INDIA PRIVATE LIMITED

### Project Overview
This project contains the complete native Android Jetpack Compose source code for **CHANDRA AUTOMOBILE VEHICLE CLEARANCE**.

- **Cloud Database:** Firebase Cloud Firestore & Authentication
- **Multi-Branch Real-Time Sync:** Data synchronizes across devices instantly.
- **Admin & Executive Roles:** Strict branch and executive view restrictions.
- **Financial Engine:** Exact formulas from Python clearance system.

### How to Build the APK Online in GitHub (100% Free):

1. Go to https://github.com and log in.
2. Click **New** (green button) to create a new repository (name it `ChandraVehicleClearance`).
3. Inside your new repository, click **Add file** -> **Upload files**.
4. Drag and drop **ChandraVehicleClearance-Android.zip** into the upload box and click **Commit changes**.
5. Click **Actions** at the top of your GitHub repository.
6. The **Build Android APK** workflow will run automatically.
7. Once finished (green checkmark), click on the build run, scroll down to **Artifacts**, and click **ChandraVehicleClearance-APK** to download your ready-to-install Android APK!
